# colour settings
HIGHLIGHT_TEXT = "#866ec0"
HIGHLIGHT_BG = "#d56f8f"

# font settings
ARIAL = "arial"
LUCIDA_CONSOLE = "Lucida Console"
