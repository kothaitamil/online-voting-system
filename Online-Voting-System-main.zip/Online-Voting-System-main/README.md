# Online-Voting-System

Desktop application for online voting system made in python using tkinter. 